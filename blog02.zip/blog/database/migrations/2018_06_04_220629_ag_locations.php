<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AgLocations extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
     Schema::create('ag_locations', function (Blueprint $table) {
      $table->increments('id');
       $table->string('model');
        $table->timestamps();
   });
     Schema::table('ag_locations', function (Blueprint $table) {
    $table->unsignedInteger('adresse_id');

    $table->foreign('adresse_id')->references('id')->on('adresses')->onDelete('cascade');
});
     Schema::table('ag_locations', function (Blueprint $table) {
    $table->unsignedInteger('service_id');

    $table->foreign('service_id')->references('id')->on('services')->onDelete('cascade');
});
      Schema::table('ag_locations', function (Blueprint $table) {
    $table->unsignedInteger('media_id');
    $table->foreign('media_id')->references('id')->on('medias')->onDelete('cascade');
});
       Schema::table('ag_locations', function (Blueprint $table) {
    $table->unsignedInteger('contact_id');
    $table->foreign('contact_id')->references('id')->on('contacts')->onDelete('cascade');
});
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}
