<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Others extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
    Schema::create('others', function (Blueprint $table) {
      $table->increments('id');
       $table->string('name');
       $table->string('type');
       //$table->unsignedInteger('madia_id');
        $table->timestamps();
   });
    Schema::table('others', function (Blueprint $table) {
    $table->unsignedInteger('adresse_id');

    $table->foreign('adresse_id')->references('id')->on('adresses')->onDelete('cascade');
});
     Schema::table('others', function (Blueprint $table) {
    $table->unsignedInteger('service_id');
    $table->foreign('service_id')->references('id')->on('services')->onDelete('cascade');
  });
       Schema::table('others', function (Blueprint $table) {
    $table->unsignedInteger('media_id');
    $table->foreign('media_id')->references('id')->on('medias')->onDelete('cascade');
});
       Schema::table('others', function (Blueprint $table) {
    $table->unsignedInteger('contact_id');
    $table->foreign('contact_id')->references('id')->on('contacts')->onDelete('cascade');
});
    }/**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}
