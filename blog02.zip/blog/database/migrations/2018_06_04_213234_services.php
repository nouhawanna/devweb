<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Services extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
    Schema::create('services', function (Blueprint $table) {
            $table->increments('id');
            $table->string('categorie');
            $table->string('name');
            $table->string('website');
            $table->longText('content');
            $table->boolean('valid');
            $table->timestamps();
        });
  

 Schema::table('services', function (Blueprint $table) {
    $table->unsignedInteger('user_id');
    $table->foreign('user_id')->references('id')->on('users')->onDelete('cascade');
});
   }
    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
    Schema::dropIfExists('services');
    }
}
