<?php $__env->startSection('content'); ?>
<div class="panel panel-default">
    <div class="panel-heading">
      <h3 style="text-align: center;" class="panel-title">Ajouter votre service</h3>
    </div>
    <div class="panel-body">
      <form name="basicform" id="create" method="POST" action="<?php echo e(route('add')); ?>" novalidate="novalidate">
        <?php echo e(csrf_field()); ?>

        <div id="sf1" class="frm">
          <fieldset>
           

            <div class="form-group">
              <label class="col-lg-2 control-label bg-shop" for="uname"></label>
            <div class="bg-shop col-lg-2"><span class="glyphicon glyphicon-pencil"></span></div>
              <div class="col-lg-6">
                <input type="text" placeholder="Non du service" id="uname" name="name" class="form-control" autocomplete="off">
              </div>
            </div>
            <div class="clearfix" style="height: 10px;clear: both;"></div>


            <div class="form-group">
              <div class="col-lg-10 col-lg-offset-2">
                <button class="btn btn-success open1" type="button">suivant <span class="fa fa-arrow-right"></span></button> 
              </div>
            </div>

          </fieldset>
        </div>

        <div id="sf2" class="frm" style="display: none;">
          <fieldset>
         


            <div class="form-group">
              <label class="col-lg-2 control-label" for="uemail">Gouvernerat</label>
              <div class="col-lg-6">
               <select class="form-control" id="wilaya" name="city">
               <option value="Ariana">Ariana</option>
<option value="Ben arous">Ben arous</option>
<option value="Bizerte">Bizerte</option>
<option value="Béja">Béja</option>
<option value="Gabès">Gabès</option>
<option value="Gafsa">Gafsa</option>
<option value="Jendouba">Jendouba</option>
<option value="Kairouan">Kairouan</option>
<option value="asserine">Kasserine</option>
<option value="Kébili">Kébili</option>
<option value="La manouba">La manouba</option>
<option value="Le kef">Le kef</option>
<option value="Mahdia">Mahdia</option>
<option value="Monastir">Monastir</option>
<option value="Médenine">Médenine</option>
<option value="Nabeul">Nabeul</option>
<option value="Sfax">Sfax</option>
<option value="Sidi bozid">Sidi bozid</option>
<option value="Siliana">Siliana</option>
<option value="Sousse">Sousse</option>
<option value="Tataouine">Tataouine</option>
<option value="Tozeur">Tozeur</option>
<option value="Tunis">Tunis</option>
<option value="Zaghouan">Zaghouan</option>

               </select>
              </div>

          
            </div>
            <div class="clearfix" style="height: 10px;clear: both;"></div>
            <div class="form-group">
              <label class="col-lg-2 control-label" for="uemail">delegation</label>
            <div class="col-lg-6" id="govs">
              <input type="text" name="town" class="form-control" placeholder="delagation">
            </div>  
            </div>

            <div class="clearfix" style="height: 10px;clear: both;"></div>
   <div class="form-group">
             
           
               <label class="col-lg-2 control-label" for="uname">Code postale</label>
           
              <div class="col-lg-6">
                <input type="text" placeholder="code postale" id="uname" name="zip_code" class="form-control" autocomplete="off">
              </div>
            </div>
<div class="clearfix" style="height: 10px;clear: both;"></div>
  <div class="form-group">
              <label class="col-lg-2 control-label" for="uname">Rue</label>
            
              <div class="col-lg-6">
                <input type="text" placeholder="rue" id="uname" name="street" class="form-control" autocomplete="off">
              </div>
            </div>
            <div class="clearfix" style="height: 10px;clear: both;"></div>
            <div class="clearfix" style="height: 10px;clear: both;"></div>

            <div class="form-group">
              <div class="col-lg-10 col-lg-offset-2">
                <button class="btn btn-warning back2" type="button"><span class="fa fa-arrow-left"></span> retour</button> 
                <button class="btn btn-primary open2" type="button">suivant <span class="fa fa-arrow-right"></span></button> 
              </div>
            </div>

          </fieldset>
        </div>

        <div id="sf3" class="frm" style="display: none;">
          <fieldset>
           

            <div class="form-group">
              <label class="col-lg-2 control-label" for="upass1">Categorie </label>
              <div class="col-lg-6">
                <select id="type" class="form-control" name="categorie">
                  
<option>Cafe</option>
<option>Restaurent</option>
<option>Hotel</option>
<option>Hospital</option>
<option>Post</option>
<option>Police</option>
<option>Parking</option>
<option>Ag_location</option>
<option>Ag_voyage</option>
<option>School</option>
<option>Autre</option>
                </select>
              </div>
            </div>
            <div class="clearfix" style="height: 10px;clear: both;"></div>

            <div id="field">

            	<div class="form-group">
              <label class="col-lg-2 control-label" for="upass1">type</label>
              <div class="col-lg-6">
                <select  class="form-control" name="type">
                <option value="normale">Normale</option>
                <option value="Salon du the">Salon du the</option>
              </select>
              </div>
            </div>
            </div>
            	
      

            

            <div class="form-group">
              <div class="col-lg-10 col-lg-offset-2">
                 <button class="btn btn-warning back2" type="button"><span class="fa fa-arrow-left"></span> retour</button> 
                <button class="btn btn-primary open3" type="button">suivant <span class="fa fa-arrow-right"></span></button>
                <img src="spinner.gif" alt="" id="loader" style="display: none">
              </div>
            </div>

          </fieldset>
        </div>
        <div id="sf4" class="frm" style="display: none;">
          <fieldset>
          

            <div class="form-group">
              <label class="col-lg-2 control-label" for="upass1">telephone </label>
              <div class="col-lg-6">
                <input type="text" class="form-control" name="phone" placeholder="numero du telephone">
              </div>
            </div>
            <div class="clearfix" style="height: 10px;clear: both;"></div>
            <div class="form-group">
              <label class="col-lg-2 control-label" for="upass1">site web</label>
              <div class="col-lg-6">
                <input type="text" class="form-control" name="website" placeholder="site web">
              </div>
            </div>
            <div class="clearfix" style="height: 10px;clear: both;"></div>
             <div class="form-group">
              <label class="col-lg-2 control-label" for="upass1">Description</label>
              <div class="col-lg-6">
                <textarea  name="content" class="form-control" placeholder="dercription"></textarea>
              </div>
            </div>
            

            

            <div class="form-group">
              <div class="col-lg-10 col-lg-offset-2">
                <button class="btn btn-warning back3" type="button"><span class="fa fa-arrow-left"></span>retour</button> 
                <input type="submit" class="btn btn-primary" value="créer">
                <img src="spinner.gif" alt="" id="loader" style="display: none">
              </div>
            </div>

          </fieldset>
        </div>
      </form>
    </div>
  </div>
  <script type="text/javascript">
  	 var v = jQuery("#create").validate({
      rules: {
        uname: {
          required: true,
          minlength: 2,
          maxlength: 16
        },
        uemail: {
          required: true,
          minlength: 2,
          email: true,
          maxlength: 100,
        },
        upass1: {
          required: true,
          minlength: 6,
          maxlength: 15,
        },
        upass2: {
          required: true,
          minlength: 6,
          equalTo: "#upass1",
        }

      },
      errorElement: "span",
      errorClass: "help-inline-error",
    });
$(".open1").click(function() {
      if (v.form()) {
        $(".frm").hide("fast");
        $("#sf2").show("slow");
      }
    });

    $(".open2").click(function() {
      if (v.form()) {
        $(".frm").hide("fast");
        $("#sf3").show("slow");
      }
    });
    
    $(".open3").click(function() {
      if (v.form()) {
        $(".frm").hide("fast");
        $("#sf4").show("slow");
      }
    });
    
    $(".back2").click(function() {
      $(".frm").hide("fast");
      $("#sf1").show("slow");
    });

    $(".back3").click(function() {
      $(".frm").hide("fast");
      $("#sf2").show("slow");
    });
    $("#type").change(function () {
    	//alert ($("#type").val());
    	if ($("#type").val()=='Cafe') {
    	var g='<div class="form-group">'+
              '<label class="col-lg-2 control-label" for="upass1">type</label>'+
              '<div class="col-lg-6">'+
                '<select  class="form-control" name="type">'+
                '<option value="normale">Normale</option>'+
                '<option value="Salon du the">Salon du the</option>'+
                '</select>'+
              '</div>'+
            '</div>';
            $("#field").empty();
$("#field").append(g);
}

if ($("#type").val()=='Hospital') {
	var g='<div class="form-group">'+
              '<label class="col-lg-2 control-label" for="upass1">type</label>'+
              '<div class="col-lg-6">'+
                '<select  class="form-control" name="type">'+
                '<option value="etatique">etatique</option>'+
                '<option value="clinique">clinique</option>'+
                '<option value="universitaire">universitaire</option>'+
                '</select>'+
              '</div>'+
            '</div>';
            $("#field").empty();
$("#field").append(g);	
}
if ($("#type").val()=='School') {
	var g='<div class="form-group">'+
              '<label class="col-lg-2 control-label" for="upass1">type</label>'+
              '<div class="col-lg-6">'+
                '<select  class="form-control" name="type">'+
                '<option value="etatique">etatique</option>'+
                '<option value="clinique">privé</option>'+
                '</select>'+
              '</div>'+
            '</div> <div class="clearfix" style="height: 10px;clear: both;"></div>'+
            '<div class="form-group">'+
              '<label class="col-lg-2 control-label" for="upass1">niveau</label>'+
              '<div class="col-lg-6">'+
                '<select  class="form-control" name="niveau">'+
                '<option value="primere">primere</option>'+
                '<option value="secondaire">secondaire</option>'+
                '<option value="universitaire">universitaire</option>'+
                '</select>'+
              '</div>'+
            '</div>';
            $("#field").empty();
$("#field").append(g);	
}
if ($("#type").val()=='Autre') {
  var g='<div class="form-group">'+
              '<label class="col-lg-2 control-label" for="upass1">Nom de type </label>'+
              '<div class="col-lg-6" >'+
                '<input name="nom_type" class="form-control" type="text">'+
              '</div>'+
            '</div><div class="clearfix" style="height: 10px;clear: both;"></div>'+
            '<div class="form-group"> '+
              '<label class="col-lg-2 control-label" for="upass1">Type</label>'+
              '<div class="col-lg-6">'+
                '<input name="type" class="form-control" type="text">'+
              '</div>'+
            '</div>';
            $("#field").empty();
$("#field").append(g);  
}
if ($("#type").val()=='Police') {
	var g='<div class="form-group">'+
              '<label class="col-lg-2 control-label" for="upass1">type</label>'+
              '<div class="col-lg-6">'+
                '<select  class="form-control" name="type">'+
                '<option value="garde nationale">garde nationale</option>'+
                '<option value="police nationale">police nationale</option>'+
                '<option value="Douane">Douane</option>'+
                '</select>'+
              '</div>'+
            '</div>';
            $("#field").empty();
$("#field").append(g);	
}
if ($("#type").val()=='Post') {
	var g='<div class="form-group">'+
              '<label class="col-lg-2 control-label" for="upass1">type</label>'+
              '<div class="col-lg-6">'+
                '<select  class="form-control" name="type">'+
                '<option value="Rapide">Rapide</option>'+
                '<option value="Normale">Normale</option>'+
                '</select>'+
              '</div>'+
            '</div>';
            $("#field").empty();
$("#field").append(g);	
}
if ($("#type").val()=='Restaurent') {
	var g='<div class="form-group">'+
              '<label class="col-lg-2 control-label" for="upass1">type</label>'+
              '<div class="col-lg-6">'+
                '<select  class="form-control" name="type">'+
                '<option value="pizzaria">pizzaria</option>'+
                '<option value="Restaurent">Restaurent</option>'+
                '</select>'+
              '</div>'+
            '</div>';
            $("#field").empty();
$("#field").append(g);	
}
if ($("#type").val()=='Parking') {
	var g='<div class="form-group">'+
              '<label class="col-lg-2 control-label" for="upass1">type</label>'+
              '<div class="col-lg-6">'+
                '<input type="text" name="nb_place" class="form-control" placeholder="nombre des places">'+
              '</div>'+
            '</div> <div class="clearfix" style="height: 10px;clear: both;"></div>'+
            '<div class="form-group">'+
              '<label class="col-lg-2 control-label" for="upass1">type</label>'+
              '<div class="col-lg-6">'+
                '<input type="text" name="price" class="form-control" placeholder="prix">'+
              '</div>'+
            '</div>';
            $("#field").empty();
$("#field").append(g);	
}
if ($("#type").val()=='Ag_voyage') {
	var g='<div class="form-group">'+
              '<label class="col-lg-2 control-label" for="upass1">type</label>'+
              '<div class="col-lg-6">'+
                '<select  class="form-control" name="type">'+
                '<option value="nationale">nationale</option>'+
                '<option value="internationale">internationale</option>'+
                '</select>'+
              '</div>'+
            '</div>';
            $("#field").empty();
            $("#field").append(g);	
}
if ($("#type").val()=='Ag_location') {
	var g='<div class="form-group">'+
              '<label class="col-lg-2 control-label" for="upass1">type</label>'+
              '<div class="col-lg-6">'+
                '<select  class="form-control" name="model">'+
                '<option value="deserte">deserte</option>'+
                '<option value="sociale">sociale</option>'+
                '</select>'+
              '</div>'+
            '</div>';
            $("#field").empty();
            $("#field").append(g);	
}
if ($("#type").val()=='Hotel') {
	var g='<div class="form-group">'+
              '<label class="col-lg-2 control-label" for="upass1">type</label>'+
              '<div class="col-lg-6">'+
                '<input type="text" name="nb_stars" class="form-control" placeholder="nombre des etoiles">'+
              '</div>'+
            '</div> <div class="clearfix" style="height: 10px;clear: both;"></div>'+
            '<div class="form-group">'+
              '<label class="col-lg-2 control-label" for="upass1">type</label>'+
              '<div class="col-lg-6">'+
                '<input type="text" name="capacity" class="form-control" placeholder="capacite">'+
              '</div>'+
            '</div>';
            $("#field").empty();
$("#field").append(g);	
}
    })

  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('navigate', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>