<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">    
    <meta http-equiv="content-type" content="text/html; charset=utf-8">
    <meta name="author" content="Clasified">
    <meta name="generator" content="Wordpress! - Open Source Content Management">
    <title>ClassiX - Bootstrap HTML5 Classified Template</title>    
<script type="text/javascript" src="<?php echo e(asset('/js/jquery-min.js')); ?>"></script>  
<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/jquery-validation@1.17.0/dist/jquery.validate.js"></script>
    <!-- Favicon -->
    <link rel="shortcut icon" href="<?php echo e(asset('/img/favicon.png')); ?>">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('/css/bootstrap.min.css')); ?>" type="text/css">    
    <link rel="stylesheet" href="<?php echo e(asset('/css/jasny-bootstrap.min.css')); ?>" type="text/css">    
    <link rel="stylesheet" href="<?php echo e(asset('/css/jasny-bootstrap.min.css')); ?>" type="text/css">
    <!-- Material CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('/css/material-kit.css')); ?>" type="text/css">
    <!-- Font Awesome CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('/css/font-awesome.min.css')); ?>" type="text/css">
        <!-- Line Icons CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('/fonts/line-icons/line-icons.css')); ?>" type="text/css">
        <!-- Line Icons CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('/fonts/line-icons/line-icons.css')); ?>" type="text/css">
    <!-- Main Styles -->
    <link rel="stylesheet" href="<?php echo e(asset('/css/main.css')); ?>" type="text/css">
    <!-- Animate CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('/extras/animate.css')); ?>" type="text/css">
    <!-- Owl Carousel -->
    <link rel="stylesheet" href="<?php echo e(asset('/extras/owl.carousel.css')); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('/extras/owl.theme.css')); ?>" type="text/css">    
    <!-- Responsive CSS Styles -->
    <!-- Slicknav js -->
    <link rel="stylesheet" href="<?php echo e(asset('/css/slicknav.css')); ?>" type="text/css">
        <!-- Bootstrap Select -->
    <link rel="stylesheet" href="<?php echo e(asset('/css/bootstrap-select.min.css')); ?>">
    
  </head>

  <body>  
    <!-- Header Section Start -->
    <div class="header">    
      <nav class="navbar navbar-default main-navigation" role="navigation">
        <div class="container">
          <div class="navbar-header">
            <!-- Stat Toggle Nav Link For Mobiles -->
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
              <span class="sr-only">Toggle navigation</span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
            </button>
            <!-- End Toggle Nav Link For Mobiles -->
            <a class="navbar-brand logo" href="<?php echo e(route('annuaire')); ?>"><img src="<?php echo e(asset('/img/logo.png')); ?>" alt=""></a>
          </div>
          <!-- brand and toggle menu for mobile End -->

          <!-- Navbar Start -->
          <div class="collapse navbar-collapse" id="navbar">
            <ul class="nav navbar-nav navbar-right">
              <?php if(auth()->check()): ?>
                <?php if(auth()->user()->isAdministrator()): ?>
                     <li class="postadd">
                <a class="btn btn-danger btn-default" href="<?php echo e(route('admin')); ?>"><span class="fa fa-plus-circle"></span> Adminstration </a>
              </li>
                <?php else: ?>
                   <li class="postadd">
                <a class="btn btn-danger btn-default" href="<?php echo e(route('dashboard')); ?>"><span class="fa fa-plus-circle"></span> Mes services </a>
              </li>
                <?php endif; ?>
 <?php endif; ?>
              <?php if(Route::has('login')): ?>
               
                    <?php if(auth()->guard()->check()): ?>
                         <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
                    <?php else: ?>
                        <li> <a href="<?php echo e(route('login')); ?>">Login</a></li>
                        <li> <a href="<?php echo e(route('register')); ?>">Register</a></li>
                    <?php endif; ?>
           
            <?php endif; ?>
              <li class="postadd">
                <a class="btn btn-danger btn-post" href="<?php echo e(route('add')); ?>"><span class="fa fa-plus-circle"></span> Ajouter service</a>
              </li>
              <?php if(Route::has('login')): ?>
               
                    <?php if(auth()->guard()->check()): ?>
                         <li class="postadd"><a href="<?php echo e(url('/logout')); ?>" class="btn btn-danger btn-default">Deconnection</a></li>
                   
                    <?php endif; ?>
           
            <?php endif; ?>
            </ul>
          </div>
          <!-- Navbar End -->
        </div>
      </nav>
      <!-- Off Canvas Navigation -->
      <div class="navmenu navmenu-default navmenu-fixed-left offcanvas"> 
      <!--- Off Canvas Side Menu -->
        <div class="close" data-toggle="offcanvas" data-target=".navmenu">
            <i class="fa fa-close"></i>
        </div>
          <h3 class="title-menu">All Pages</h3>
          <ul class="nav navmenu-nav"> <!--- Menu -->
            <li><a href="index.html">Home</a></li>
            <li><a href="index-v-2.html">Home Page V2</a></li>
            <li><a href="about.html">About us</a></li>            
            <li><a href="category.html">Category</a></li>             
            <li><a href="ads-details.html">Ads details</a></li>    
            <li><a href="pricing.html">Pricing Tables</a></li>    
            <li><a href="account-archived-ads.html">Account archived</a></li>
            <li><a href="account-close.html">Account-close</a></li>
            <li><a href="account-favourite-ads.html">Favourite ads</a></li>
            <li><a href="account-home.html">Account home</a></li>
            <li><a href="account-myads.html">Account myads</a></li>
            <li><a href="account-pending-approval-ads.html">pending approval</a></li>
            <li><a href="account-saved-search.html">saved search</a></li> 
            <li><a href="post-ads.html">Post ads</a></li> 
            <li><a href="posting-success.html">Posting-success</a></li>  
            <li><a href="blog.html">Blogs</a></li>
            <li><a href="blog-details.html">Blog Details</a></li>
            <li><a href="contact.html">Contact</a></li>
            <li><a href="forgot-password.html">Forgot-password</a></li>
            <li><a href="faq.html">Faq</a></li>
            <li><a href="signup.html">Signup</a></li>
        </ul><!--- End Menu -->
      </div> <!--- End Off Canvas Side Menu -->
      <div class="tbtn wow pulse" id="menu" data-wow-iteration="infinite" data-wow-duration="500ms" data-toggle="offcanvas" data-target=".navmenu">
        <p><i class="fa fa-file-text-o"></i> All Pages</p>
      </div>
    </div>
    <!-- Header Section End -->

    <!-- Start intro section -->
    <section id="intro" class="section-intro">
      <div class="overlay">
        <div class="container">
         
        </div>
      </div>
    </section>
    <!-- end intro section -->

    <div class="wrapper">
      <!-- Categories Homepage Section Start -->
     <?php echo $__env->yieldContent('content'); ?>
      <!-- Featured Listings End -->

      <!-- Start Services Section -->
  
      <!-- End Services Section -->
     
      <!-- Location Section Start -->
   
      <!-- Location Section End -->

    </div>

    <!-- Counter Section Start -->
    
    <!-- Counter Section End -->

    <!-- Footer Section Start -->
    <footer style="margin-bottom: 0px;!important">
      <!-- Footer Area Start -->
   
      <!-- Footer area End -->
      
      <!-- Copyright Start  -->
      <div id="copyright">
        <div class="container">
          <div class="row">
            <div class="col-md-12">
              <div class="site-info pull-left">
                <p>All copyrights reserved @ 2016 - Designed by <a rel="nofollow" href="http://graygrids.com">GrayGrids</a></p>
              </div>              
              <div class="bottom-social-icons social-icon pull-right">  
                <a class="facebook" target="_blank" href="https://web.facebook.com/GrayGrids"><i class="fa fa-facebook"></i></a> 
                <a class="twitter" target="_blank" href="https://twitter.com/GrayGrids"><i class="fa fa-twitter"></i></a>
                <a class="dribble" target="_blank" href="https://dribbble.com/"><i class="fa fa-dribbble"></i></a>
                <a class="flickr" target="_blank" href="https://www.flickr.com/"><i class="fa fa-flickr"></i></a>
                <a class="youtube" target="_blank" href="https://youtube.com"><i class="fa fa-youtube"></i></a>
                <a class="google-plus" target="_blank" href="https://plus.google.com"><i class="fa fa-google-plus"></i></a>
                <a class="linkedin" target="_blank" href="https://www.linkedin.com/"><i class="fa fa-linkedin"></i></a>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- Copyright End -->

    </footer style="margin-bottom: 0px">
    <!-- Footer Section End -->  
    
    <!-- Go To Top Link -->
    
      
    <!-- Main JS  -->
    <script type="text/javascript" src="<?php echo e(asset('/js/jquery-min.js')); ?>"></script>      
    <script type="text/javascript" src="<?php echo e(asset('/js/bootstrap.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('/js/material.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('/js/material-kit.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('/js/jquery.parallax.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('/js/owl.carousel.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('/js/wow.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('/js/main.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('/js/jquery.counterup.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('/js/waypoints.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('/js/jasny-bootstrap.min.js')); ?>"></script>
        <script src="<?php echo e(asset('/js/bootstrap-select.min.js')); ?>"></script>

    
  </body>
</html>