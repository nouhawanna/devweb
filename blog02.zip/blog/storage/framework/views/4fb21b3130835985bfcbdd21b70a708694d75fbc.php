<?php $__env->startSection('content'); ?>
<style type="text/css">
	@import  "//netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.min.css";

.social {
    margin: 0;
    padding: 0;
}

.social ul {
    margin: 0;
    padding: 5px;
}

.social ul li {
    margin: 5px;
    list-style: none outside none;
    display: inline-block;
}

.social i {
    width: 80px;
    height: 80px;
    color: #FFF;
    background-color: #909AA0;
    font-size: 44px;
    text-align:center;
    padding-top: 24px;
  
    transition: all ease 0.3s;
    -moz-transition: all ease 0.3s;
    -webkit-transition: all ease 0.3s;
    -o-transition: all ease 0.3s;
    -ms-transition: all ease 0.3s;
}

.social i:hover {
    color: #FFF;
    text-decoration: none;
    transition: all ease 0.3s;
    -moz-transition: all ease 0.3s;
    -webkit-transition: all ease 0.3s;
    -o-transition: all ease 0.3s;
    -ms-transition: all ease 0.3s;
}

.social .fa-coffee:hover {
    background: #4060A5;
}

.social .fa-plane:hover {
    background: #00ABE3;
}

.social .fa-car:hover {
    background: #e64522;
}

.social .fa-cab:hover {
    background: #343434;
}

.social .fa-beer:hover {
    background: #cb2027;
}

.social .fa-hotel:hover {
    background: #0094BC;
}

.social .fa-heartbeat:hover {
    background: #FF57AE;
}

.social .fa-cc-visa:hover {
    background: #375989;
}

.social .fa-clock-o:hover {
    background: #83DAEB;
}
.social .fa-briefcase:hover {
    background: #cb2027;
}


</style>
<div class="container">
	<div class="row col-md-6 col-md-offset-3">
		<div class="social">
            <ul>
                <li><a href="admin/cafes"><i class="fa fa-lg fa-coffee"></i></a></li>
                <li><a href="admin/ag_locations"><i class="fa fa-lg fa-car"></i></a></li>
                <li><a href="admin/hotels"><i class="fa fa-lg fa-hotel"></i></a></li>
                <li><a href="admin/polices"><i class="fa fa-lg fa-cab"></i></a></li>
                <li><a href="admin/hospitals"><i class="fa fa-lg fa-heartbeat"></i></a></li>
                <li><a href="admin/ag_voyages"><i class="fa fa-lg fa-plane"></i></a></li>
                <li><a href="admin/restaurents"><i class="fa fa-lg fa-beer"></i></a></li>
                <li><a href="admin/schools"><i class="fa fa-lg fa-briefcase"></i></a></li>
                <li><a href="admin/posts"><i class="fa fa-lg fa-cc-visa"></i></a></li>
                <li><a href="admin/parkings"><i class="fa fa-lg fa-clock-o"></i></a></li>
            </ul>
        </div>
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('navigate', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>