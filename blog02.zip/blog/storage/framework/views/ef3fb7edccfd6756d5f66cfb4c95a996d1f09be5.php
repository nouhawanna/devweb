<?php $__env->startSection('content'); ?>
<style type="text/css">
	.widget .panel-body { padding:0px; }
.widget .list-group { margin-bottom: 0; }
.widget .panel-title { display:inline }
.widget .label-info { float: right; }
.widget li.list-group-item {border-radius: 0;border: 0;border-top: 1px solid #ddd;}
.widget li.list-group-item:hover { background-color: rgba(86,61,124,.1); }
.widget .mic-info { color: #666666;font-size: 11px; }
.widget .action { margin-top:5px; }
.widget .comment-text { font-size: 12px; }
.widget .btn-block { border-top-left-radius:0px;border-top-right-radius:0px; }
</style>
<div class="container">
    <div class="row">
        <div class="panel panel-default widget">
            <div class="panel-heading">
                <span class="glyphicon glyphicon-comment"></span>
                <h3 class="panel-title">
                   Services non valider</h3>
                <span class="label label-info">
                <?php echo e($product->count()); ?></span>
            </div>
            <div class="panel-body">
                <ul class="list-group">
                	<?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="list-group-item">
                        <div class="row">
                            <div class="col-xs-2 col-md-1">
                                <img src="<?php echo e($value->image->url); ?>" class="img-circle img-responsive" alt="" /></div>
                            <div class="col-xs-10 col-md-11">
                                <div>
                                    <h3> <?php echo e($value->service->name); ?></h3>
                                       
                                    <div class="mic-info">
                                        <?php echo e($value->adresse->city); ?> <a href="#"><?php echo e($value->adresse->town); ?></a><?php echo e($value->adresse->street); ?>

                                    </div>
                                </div>
                                <div class="comment-text">
                                    <?php echo e($value->type); ?>

                                </div>
                                <div class="action">
                                   
                                    <a href="/validates/<?php echo e($value->service->id); ?>/<?php echo e($name); ?>" type="button" class="btn btn-success btn-xs" title="Approved">
                                        <span class="glyphicon glyphicon-ok"></span>
                                    </a>
                                    <a href="/deletes/<?php echo e($value->id); ?>/<?php echo e($name); ?>" type="button" class="btn btn-danger btn-xs" title="Delete">
                                        <span class="glyphicon glyphicon-trash"></span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('navigate', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>