@extends('navigate')
@section('content')
<style type="text/css">
	   input.hidden {
    position: absolute;
    left: -9999px;
}

#profile-image1 {
    cursor: pointer;
  
     width: 100px;
    height: 100px;
	border:2px solid #03b1ce ;}
	.tital{ font-size:16px; font-weight:500;}
	 .bot-border{ border-bottom:1px #f8f8f8 solid;  margin:5px 0  5px 0}	
</style>
<div class="container">
	<div class="row">
		<h2> editer votre service</h2>
    <div class="col-md-12 ">

<div class="panel panel-default">
  <div class="panel-heading">  <h4 >service Profile</h4></div>
   <div class="panel-body">
       <form method="post" action="{{ route('update') }}" enctype="multipart/form-data">
        {{ csrf_field() }}
    <div class="box box-info">
        
            <div class="box-body">
                     <div class="col-sm-6">
                     <div  align="center"> <img alt="User Pic" src="{{$product->image->url}}" id="profile-image1" class="img-circle img-responsive"> 
                
                <input id="profile-image-upload" class="hidden" name="logo" type="file">
<div style="color:#999;" >click here to change profile image</div>
                <!--Upload Image Js And Css-->
           
              
   
                
                
                     
                     
                     </div>
              
              <br>
    
              <!-- /input-group -->
            </div>
            <div class="col-sm-6">
            <h4 style="color:#00b1b1;">{{$product->service->name}}</h4></span>
              <span><p>{{$product->type}}</p></span>            
            </div>
            <div class="clearfix"></div>
            <hr style="margin:5px 0 5px 0;">
    
              
<div class="col-sm-5 col-xs-6 tital " >Nom:</div><div class="col-sm-7 col-xs-6 ">
<div class="form-group">
<input type="hidden" name="id" value="{{$pos->id}}">
<input type="hidden" name="name" value="{{$pos->name}}">
		<input type="text" name="name_service" class="form-control" value="{{$product->service->name}}">
	</div></div>
     <div class="clearfix"></div>
<div class="bot-border"></div>

<div class="col-sm-5 col-xs-6 tital " >Site web:</div><div class="col-sm-7">
	<div class="form-group">
		<input type="text" name="website" class="form-control" value="{{$product->service->website}}">
	</div>
</div>
  <div class="clearfix"></div>
<div class="bot-border"></div>

<div class="col-sm-5 col-xs-6 tital " >Rue:</div><div class="col-sm-7">
 <div class="form-group">
		<input type="text" name="street" class="form-control" value="{{$product->adresse->street}}">
	</div></div>
  <div class="clearfix"></div>
<div class="bot-border"></div>

<div class="col-sm-5 col-xs-6 tital " >Code postal:</div><div class="col-sm-7">
<div class="form-group">
		<input type="text" name="zip_code" class="form-control" value="{{$product->adresse->zip_code}}">
	</div></div>

  <div class="clearfix"></div>
<div class="bot-border"></div>

<div class="col-sm-5 col-xs-6 tital " >Telephone:</div><div class="col-sm-7">
<div class="form-group">
		<input type="text" name="phone" class="form-control">
	</div></div>

  <div class="clearfix"></div>
<div class="bot-border"></div>

<div class="col-sm-5 col-xs-6 tital " >Fax:</div><div class="col-sm-7">
<div class="form-group">
		<input type="text" name="fax" class="form-control">
	</div></div>

 <div class="clearfix"></div>
<div class="bot-border"></div>

<div class="col-sm-5 col-xs-6 tital " >Ville:</div><div class="col-sm-7">
<div class="form-group">
		<input type="text" name="town" class="form-control" value="{{$product->adresse->town}}">
	</div></div>

 <div class="clearfix"></div>
<div class="bot-border"></div>

<div class="col-sm-5 col-xs-6 tital " >Description:</div>
<div class="col-sm-7">
<div class="form-group">
		<textarea class="form-control" name="content" >{{$product->service->content}}</textarea>
	</div>
</div>
 <div class="clearfix"></div>
<div class="bot-border"></div>
<input type="submit"  class="btn btn-primary" value="Update">
<a href="#" class="btn btn-danger" >annuler</a>
</form>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->

        </div>
       
            
    </div> 
    </div>
</div>  
    <script>
              $(function() {
    $('#profile-image1').on('click', function() {
        $('#profile-image-upload').click();
    });
});       
              </script> 
       
       
       
       
       
       
       
       
       
   </div>
</div>

@stop