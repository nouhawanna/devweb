@extends('navigate')
@section('content')
<style type="text/css">
	.widget .panel-body { padding:0px; }
.widget .list-group { margin-bottom: 0; }
.widget .panel-title { display:inline }
.widget .label-info { float: right; }
.widget li.list-group-item {border-radius: 0;border: 0;border-top: 1px solid #ddd;}
.widget li.list-group-item:hover { background-color: rgba(86,61,124,.1); }
.widget .mic-info { color: #666666;font-size: 11px; }
.widget .action { margin-top:5px; }
.widget .comment-text { font-size: 12px; }
.widget .btn-block { border-top-left-radius:0px;border-top-right-radius:0px; }
</style>
<div class="container">
    <div class="row">
        <div class="panel panel-default widget">
            <div class="panel-heading">
                <span class="glyphicon glyphicon-comment"></span>
                <h3 class="panel-title">
                   Services non valider</h3>
                <span class="label label-info">
                {{$product->count()}}</span>
            </div>
            <div class="panel-body">
                <ul class="list-group">
                	@foreach ($product as $key =>$value)
                    <li class="list-group-item">
                        <div class="row">
                            <div class="col-xs-2 col-md-1">
                                <img src="{{$value->image->url}}" class="img-circle img-responsive" alt="" /></div>
                            <div class="col-xs-10 col-md-11">
                                <div>
                                    <h3> {{$value->service->name}}</h3>
                                       
                                    <div class="mic-info">
                                        {{$value->adresse->city}} <a href="#">{{$value->adresse->town}}</a>{{$value->adresse->street}}
                                    </div>
                                </div>
                                <div class="comment-text">
                                    {{$value->type}}
                                </div>
                                <div class="action">
                                   
                                    <a href="/validates/{{$value->service->id}}/{{$name}}" type="button" class="btn btn-success btn-xs" title="Approved">
                                        <span class="glyphicon glyphicon-ok"></span>
                                    </a>
                                    <a href="/deletes/{{$value->id}}/{{$name}}" type="button" class="btn btn-danger btn-xs" title="Delete">
                                        <span class="glyphicon glyphicon-trash"></span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </li>
                    @endforeach
                </ul>
                
            </div>
        </div>
    </div>
</div>

@stop