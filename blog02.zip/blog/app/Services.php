<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Services extends Model
{
   protected $fillable = ['name', 'content','website'];

    public function user()
    {
     return $this->belongsTo(User::class,'user_id');
    }
}
