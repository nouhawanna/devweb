<?php

namespace App\Http\Controllers;
use App\Adresses;
use App\Medias;
use App\Services;
use App\Cafes;
use App\Hospitals;
use App\Hotels;
use App\Schools;
use App\Posts;
use App\Restaurents;
use App\Ag_locations;
use App\Ag_voyages;
use App\Parkings;
use App\Polices;
use App\Contacts;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class ServicesController extends Controller
{
	public function __contruct()
{
    $this->middleware('auth');
}
public function dashboard()
{
$namespace=new Services;
$id= Auth::user()->id ;
$srv=$namespace::where('user_id',$id)->get();
//var_dump($srv);
//dd($srv);
  return view('user.dashboard',compact('srv'));
}
public function deletes($id,$name)
{
  if (Auth::user()->role=='admin') {
  $namespace='App\\'.ucfirst($name);
            if (class_exists($namespace)) {
                $namespace=new $namespace;
                $item=$namespace::where('id',$id)->delete();

            }
            return redirect('/admin/'.$name);
  }else{
    $service= new Services;
    $up=$service::where('id',$id)->first();
    if ($up->user_id=Auth::user()->id) {
     $namespace='App\\'.ucfirst($name);
            if (class_exists($namespace)) {
                $namespace=new $namespace;
                $item=$namespace::where('service_id',$id)->delete();
                $up->delete();
                return redirect('dashboard');
    }
  }
     
}
return redirect('/');
}
public function validates($id,$name)
{
  if (Auth::user()->role!=='admin') {
    return redirect('/');
  }
    $service= new Services;
    $up=$service::where('id',$id)->first();
    $up->valid=true;
    $up->save();
   // dd($up);
    return redirect('/admin/'.$name);

}
public function valid($name='')
{
  if (Auth::user()->role!=='admin') {
    return redirect('/');
  }
     $namespace='App\\'.ucfirst($name);
            if (class_exists($namespace)) {
                $namespace=new $namespace;
                //echo $namespace->exists();
                $product=$namespace::whereHas('service',function($query) {
            $query->where('valid',0);
            })->get();}
 return view("admin.valid",['product'=>$product,'name'=>$name]);   
}
public function admin_index($value='')
{
  //echo Auth::user()->role;
  if (Auth::user()->role!=='admin') {
   // echo "0000";
   return redirect('/');
  }
   return view("admin.index");  
}
  public function edit($id='',$name=null)
  {
  $namespace='App\\'.ucfirst($name);
    		if (class_exists($namespace)) {
    			$namespace=new $namespace;
    			//echo $namespace->exists();
    			$product=$namespace::where('service_id',$id)->first();
                 $pos=new \stdClass();
                $pos->id=$product->id;
                $pos->name=$name;
    		}
    		//dd($product->service->name
                		//dd($product);
        
  return view("services.edit",compact('product','pos'));
  }
  public function update(Request $request)
  {
    //dd($request->input());
    $id=$request->input('id');
    $namespace='App\\'.ucfirst($request->input('name'));
            if (class_exists($namespace)) {
                //$namespace=new $namespace;
                $product=$namespace::where('id',$request->input('id'))->first();
                //dd($product);
                $service=Services::where('id',$product->service_id)->first();
               $service->name=$request->input('name_service');
                $service->website=$request->input('website');
                 $service->content=$request->input('content');
               $service->save();
               $adresse=Adresses::where('id',$product->adresse_id)->first();
               $adresse->street=$request->input('street');
               //$adresse->city=$request->input('city');
               $adresse->town=$request->input('town');
               $adresse->zip_code=$request->input('zip_code');
               $adresse->save();

               // echo $namespace->exists();
                $product=$namespace::where('id',$id)->first();
                $pos=new \stdClass();
                $pos->id=$request->input('id');
                $pos->name=$request->input('name');
                 
            }else{
              // dd($product); 
            }
//die();
    return view("services.edit",compact('product','pos'));
  }
	public function index($value='')
	{
		# code...
	}
    public function add_service(Request $request)
    {
    	//dd($request->input());
      return view("services/add");
    }
    public function store_service(Request $request)
    {
    	
    	if (Auth::user('id')===null) {
    		return redirect()->intended('login');

    	}
    	$adresse=new Adresses;

    	$adresse->street=$request->input('street');
    		$adresse->city=$request->input('city');
    		$adresse->zip_code=$request->input('zip_code');
    	$adresse->town=$request->input('town');
    	$adresse->save();
    	//dd($adresse->id);
    	$service=new Services;
    	$service->name=$request->input('name');
    	$service->content=$request->input('content');
    	$service->website=$request->input('website');
    	$service->valid=false;
      $service->user_id=Auth::id();
      $service->categorie=$request->input('categorie').'s';
    	$service->save();
    	//dd($service);
    	settype($type, 'string');
    	$type=$request->input('categorie');
if ($type=='Autre') {
 $type='Other';
}
    	$type='App\\'.$type.'s';
    	//echo $type;
        $media= new Medias;
        $media->url='/img/logo.png';
        $media->save();
    	$type1=new $type;
      $contact=new Contacts;
      $contact->phone='';
      $contact->fax='';
      $contact->mail='';
      $contact->save();

    	if ($type=='App\Cafes') {
    		$type1->type=$request->input('type');
    		$type1->adresse_id=$adresse->id;
    		$type1->service_id=$service->id;
            $type1->media_id=$media->id;
            $type1->contact_id=$contact->id;
    		$type1->save();

    	}
      if ($type=='App\Others') {
        $type1->type=$request->input('nom_type');
        $type1->name=$request->input('type');
        $type1->adresse_id=$adresse->id;
        $type1->service_id=$service->id;
            $type1->media_id=$media->id;
            $type1->contact_id=$contact->id;
        $type1->save();

      }

      if ($type=='App\Restaurents') {
        $type1->type=$request->input('type');
        $type1->adresse_id=$adresse->id;
        $type1->service_id=$service->id;
            $type1->media_id=$media->id;
            $type1->contact_id=$contact->id;
        $type1->save();

      }
      if ($type=='App\Posts') {
        $type1->type=$request->input('type');
        $type1->adresse_id=$adresse->id;
        $type1->service_id=$service->id;
            $type1->media_id=$media->id;
            $type1->contact_id=$contact->id;
        $type1->save();

      }
      if ($type=='App\Schools') {
        $type1->type=$request->input('type');
         $type1->niveau=$request->input('niveau');
        $type1->adresse_id=$adresse->id;
        $type1->service_id=$service->id;
            $type1->media_id=$media->id;
            $type1->contact_id=$contact->id;
        $type1->save();

      }
      if ($type=='App\Polices') {
        $type1->type=$request->input('type');
        $type1->adresse_id=$adresse->id;
        $type1->service_id=$service->id;
            $type1->media_id=$media->id;
            $type1->contact_id=$contact->id;
        $type1->save();

      }
      if ($type=='App\Hospitals') {
        $type1->type=$request->input('type');
        $type1->adresse_id=$adresse->id;
        $type1->service_id=$service->id;
            $type1->media_id=$media->id;
            $type1->contact_id=$contact->id;
        $type1->save();

      }
      if ($type=='App\Ag_voyages') {
        $type1->type=$request->input('type');
        $type1->adresse_id=$adresse->id;
        $type1->service_id=$service->id;
            $type1->media_id=$media->id;
            $type1->contact_id=$contact->id;
        $type1->save();

      }
      if ($type=='App\Ag_locations') {
        $type1->model=$request->input('model');
        $type1->adresse_id=$adresse->id;
        $type1->service_id=$service->id;
            $type1->media_id=$media->id;
            $type1->contact_id=$contact->id;
        $type1->save();

      }
      if ($type=='App\Parkings') {
        $type1->nb_place=$request->input('nb_place');
         $type1->price=$request->input('price');
        $type1->adresse_id=$adresse->id;
        $type1->service_id=$service->id;
            $type1->media_id=$media->id;
            $type1->contact_id=$contact->id;
        $type1->save();
    	}if ($type=='App\Hotels') {
        $type1->nb_stars=$request->input('nb_stars');
         $type1->capacity=$request->input('capacity');
        $type1->adresse_id=$adresse->id;
        $type1->service_id=$service->id;
            $type1->media_id=$media->id;
            $type1->contact_id=$contact->id;
        $type1->save();}

      //dd($type1);

    	//dd($request->input());
      return view("services/add");
    }
}
