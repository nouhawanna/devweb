<?php

namespace App\Http\Controllers;
use App\Adresses;
use App\Services;
use Illuminate\Http\Request;

class SearchController extends Controller
{
    public function index(Request $request)
    {
    return view("search.index");
    }
    public function store(Request $request)
    	{
    		//$adressses=new Adresses;
    		//$adresssese=$adressses::where('city',$request->input('location'))->get();
            //print_r($adresssese);
    		$namespace='App\\'.$request->input('category').'s';
             
              	//print_r($adr);
    	//$namespace::where('adresse_id',$adr->id)->get();
    
    	//print_r($item);
    	//$service=new Services;
    	
    		//$service=$service::where('name','like',$request->input('keyword'))->get();
    		$key='';
    		$location=$request->input('location');
    		if ($request->input('keyword')!==null) {
    			$key=$request->input('keyword');

    			$locale=$namespace::whereHas('adresse',function($query) use($location){
    		$query->where('city',$location);
    	})->whereHas('service',function($query) use($key){
    		 $query->where('name', 'like', $key);
    	})->whereHas('service',function($query) use($key){
             $query->where('valid',true);
        })->get();
    		}elseif ($request->input('keyword')==null) {
    				$locale=$namespace::whereHas('adresse',function($query) use($location){
    		$query->where('city',$location);
    	})->whereHas('service',function($query) use($key){
             $query->where('valid',true);
        })->get();
    		}

    
    	
    
  
    	//print_r($adresse);
    		//print_r($item);
    //dd($request->input());
return view("search.store",['locale'=>$locale]);
    	}
    	public function show($name)
    	{
    		$namespace='App\\'.ucfirst($name);
    		if (class_exists($namespace)) {
    			$namespace=new $namespace;
    			//echo $namespace->exists();
    			$product=$namespace::whereHas('service',function($query) {
             $query->where('valid',true);
        })->get();
    		}
    		
    		return view("search.show",['product'=>$product]);
    	}
}
