<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Ag_voyages extends Model
{
    public function service()
    {
     return $this->belongsTo(Services::class,'service_id');
    }
      public function adresse()
    {
     return $this->belongsTo(Adresses::class,'adresse_id');
    }
     public function image()
    {
     return $this->belongsTo(Medias::class,'media_id');
    }
      public function contact()
    {
     return $this->belongsTo(Contacts::class,'contact_id');
    }
}
