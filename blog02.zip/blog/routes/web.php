<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::get('/dashboard', 'ServicesController@dashboard')->name('dashboard');
Route::get('/logout', 'Auth\LoginController@logout')->name('logout');
Route::get('deletes/{id}/{name}','ServicesController@deletes', function($id)
{
 return $id;
})
->where('id', '[0-9]+','name', '[A-Za-z]+');
Route::get('validates/{id}/{name}','ServicesController@validates', function($id)
{
 return $id;
})
->where('id', '[0-9]+','name', '[A-Za-z]+');
Route::get('admin/{name}','ServicesController@valid',['middleware' => 'auth', function($name)
{
	if (Auth::user()->role!=='admin') {
		return redirect('/');
	}
  return $name;
}]);
Route::get('/admin', 'ServicesController@admin_index',function(){
	//echo Auth::user()->role;
	if (Auth::user()->role!=='admin') {
		return redirect('/');
	}
})->name('admin');
Route::get('search/service/{name}','SearchController@show', function($name)
{
  return $name;
})
->where('name', '[A-Za-z]+');

Route::get('service/edit/{id}/{name}','ServicesController@edit', function($id)
{
  return $name;
})
->where('id', '[0-9]+','name', '[A-Za-z]+');
Route::post('update','ServicesController@update')
->where('id', '[0-9]+','name', '[A-Za-z]+')->name('update');
Route::get('/', function () {
    return view('/search/index');
})->name('annuaire');
Route::get('add', 'ServicesController@add_service',['middleware' => 'auth', function () {
    return View::make('addThreadForm');
}])->name('add');
Route::post('add', 'ServicesController@store_service')->name('store');
Route::get('/search', 'SearchController@index');
Route::post('/search','SearchController@store')->name('search.store');
Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
